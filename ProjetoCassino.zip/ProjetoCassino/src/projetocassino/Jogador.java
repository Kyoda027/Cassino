package projetocassino;

public class Jogador {

    private int idjogadir;
    private String nome;
    private String sobrenome;
    private String apelido;
    private int cpf;
    private String nacionalidade;
    private int dataNascimento;
    
    Jogador j1 = new Jogador();
    
    public void main(){
        
    }
    public void menu(){
        
    }
    public void metodoAposta(){
        
    }
}
