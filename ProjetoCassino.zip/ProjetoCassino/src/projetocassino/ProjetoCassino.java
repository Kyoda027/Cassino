package projetocassino;

import java.util.Scanner;

public class ProjetoCassino {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Criando um objeto da classe Jogo seguindo os padrões estabelicidos
        Jogo jogo = new Jogo(1, "Par ou Ímpar", 100, 180);

        // Solicitando ao jogador que faça uma aposta e escolha par ou ímpar
        System.out.print("Digite o valor da aposta: ");
        double valorAposta = scanner.nextDouble();

        System.out.print("Escolha (P) para par ou (I) para ímpar: ");
        char escolha = scanner.next().toUpperCase().charAt(0);

        // Chamando o método jogarParImpar para realizar o jogo
        double premio = jogo.jogarParImpar(valorAposta, escolha);

        // Exibindo o resultado do jogo
        if (premio > 0) {
            System.out.println("Parabéns, você ganhou! Seu prêmio é: " + premio);
        } else if (premio < 0) {
            System.out.println("Que pena, você perdeu tudo que apostou.");
        } else {
            System.out.println("Aposta inválida. Por favor, aposte um valor entre " + jogo.getApostaMin() + " e " + jogo.getApostaMax());
        }

        scanner.close();
    }
}

