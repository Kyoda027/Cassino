package projetocassino;

public class Aposta {
    private int idaposta;
    private double valoraposta;
    private int repetir;
    
    Aposta Ap = new Aposta();
    
    public void CashOut(){
        
    }
}
