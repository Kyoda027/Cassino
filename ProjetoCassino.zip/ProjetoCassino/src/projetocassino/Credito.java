package projetocassino;

public class Credito {

    private double saldo;
    private int validade;
    private String moeda;
    private boolean bloqueado;
    private int bonus;
    
    public void ChecarBonus(){
        
    }
}
