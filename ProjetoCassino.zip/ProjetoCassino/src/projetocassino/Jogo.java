package projetocassino;

import java.util.Random;

public class Jogo {

    private int idJogo;
    private String descricao;
    private double apostaMax = 100;
    private double apostaMin = 2;
    private double premioMax;

    // Construtor
    public Jogo(int idJogo, String descricao, double apostaMax, double premioMax) {
        this.idJogo = idJogo;
        this.descricao = descricao;
        this.apostaMax = apostaMax;
        this.premioMax = premioMax;
    }

    public double getApostaMin() {
        return apostaMin;
    }

    public double getApostaMax() {
        return apostaMax;
    }

    // Método para verificar se uma aposta é válida
    public boolean validarAposta(double valorAposta) {
        return valorAposta >= apostaMin && valorAposta <= apostaMax;
    }

    // Método para jogar Par ou Ímpar
    public double jogarParImpar(double valorAposta, char escolha) {
        if (!validarAposta(valorAposta)) {
            return 0; // Retorna 0 como sinal de aposta inválida
        }

        Random random = new Random();
        int numeroAleatorio = random.nextInt(101); // Gera um número aleatório entre 0 e 100

        System.out.println("O número aleatório gerado é: " + numeroAleatorio);

        boolean resultado;
        if (numeroAleatorio % 2 == 0) {
            resultado = escolha == 'P';
        } else {
            resultado = escolha == 'I';
        }

        if (resultado) {
            return valorAposta * 1.8; // Retorna o montante ganho (aposta * 1.8) se o jogador acertar
        } else {
            return -valorAposta; // Retorna o valor da aposta negativo para representar a perda
        }
    }
}
